function e(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`)}var t=`http://localhost:8787`,n=`http://localhost:5173`,r=`simply-research-widget`;function i(e){return document.querySelector(`meta[name="${e}"], meta[property="${e}"]`)?.content}function a(e){return[`arxiv.org`,`openreview.net`,`biorxiv.org`,`medrxiv.org`,`ssrn.com`,`aclanthology.org`,`proceedings.mlr.press`,`papers.nips.cc`,`neurips.cc`,`ieee.org`,`springer.com`,`sciencedirect.com`,`nature.com`,`science.org`,`frontiersin.org`,`plos.org`].some(t=>e.endsWith(t))}function o(){let e=window.location.hostname.toLowerCase(),t=window.location.pathname.toLowerCase(),n=document.body.innerText.toLowerCase(),r=!!i(`citation_title`)||!!i(`citation_pdf_url`)||!!i(`dc.title`),o=/\babstract\b/.test(n)&&/\b(introduction|references|method|methods|results|conclusion)\b/.test(n);return a(e)||t.endsWith(`.pdf`)||/^\/pdf\//.test(t)||r||/\bdoi:\s*10\.\d{4,9}\//i.test(document.body.innerText)||o}function s(){let e=window.getSelection()?.toString().trim(),t=document.body.innerText.trim(),n=e||t;return{title:i(`citation_title`)||i(`dc.title`)||document.title.replace(/\s+-\s+Google Chrome$/,``)||`Untitled research paper`,url:window.location.href,text:n?n.slice(0,8e4):void 0}}function c(t){return(t??[]).slice(0,3).map(t=>`<li><span>${e(t.area)}</span><strong>${e(t.title)}</strong></li>`).join(``)}function l(){if(document.getElementById(r)||!o())return;let e=document.createElement(`div`);e.id=r;let i=e.attachShadow({mode:`open`});i.innerHTML=`
    <style>
      :host {
        all: initial;
        color-scheme: light;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      .panel {
        animation: slide-in 420ms cubic-bezier(0.22, 1, 0.36, 1);
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(22px) saturate(180%);
        border: 1px solid rgba(0, 0, 0, 0.08);
        border-radius: 22px;
        box-shadow: 0 24px 64px rgba(15, 23, 42, 0.14);
        box-sizing: border-box;
        color: #111;
        padding: 16px;
        position: fixed;
        right: 24px;
        top: 24px;
        width: 320px;
        max-height: min(72vh, 600px);
        overflow-y: auto;
        z-index: 2147483647;
      }

      .top {
        align-items: center;
        display: flex;
        justify-content: space-between;
        gap: 12px;
      }

      .brand {
        font-size: 13px;
        font-weight: 650;
        letter-spacing: -0.02em;
      }

      .pill {
        border: 1px solid rgba(232, 100, 42, 0.28);
        border-radius: 999px;
        color: #c24a1a;
        font-size: 11px;
        padding: 5px 8px;
      }

      h3 {
        font-size: 18px;
        font-weight: 520;
        letter-spacing: -0.03em;
        line-height: 1.12;
        margin: 14px 0 8px;
      }

      p, .status {
        color: rgba(0, 0, 0, 0.62);
        font-size: 14px;
        line-height: 1.5;
        margin: 0;
      }

      .actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 14px;
      }

      .open {
        margin-top: 12px;
        width: 100%;
      }

      button {
        border: 0;
        border-radius: 999px;
        cursor: pointer;
        font: inherit;
        font-size: 13px;
        min-height: 36px;
        padding: 0 13px;
      }

      .primary {
        background: #111;
        color: #fff;
      }

      .secondary {
        background: rgba(0, 0, 0, 0.05);
        color: rgba(0, 0, 0, 0.68);
      }

      ul {
        display: grid;
        gap: 8px;
        list-style: none;
        margin: 14px 0 0;
        padding: 0;
      }

      li {
        background: rgba(0, 0, 0, 0.035);
        border-radius: 12px;
        color: #111;
        padding: 10px 12px;
      }

      li span {
        color: #5b4bff;
        display: block;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.12em;
        margin-bottom: 4px;
        text-transform: uppercase;
      }

      li strong {
        display: block;
        font-size: 14px;
        font-weight: 600;
      }

      @keyframes slide-in {
        from {
          opacity: 0;
          transform: translateY(-12px) translateX(18px);
        }

        to {
          opacity: 1;
          transform: translateY(0) translateX(0);
        }
      }
    </style>
    <section class="panel" aria-label="Simply research paper helper">
      <div class="top">
        <span class="brand">Simply</span>
        <span class="pill">Paper detected</span>
      </div>
      <h3>This looks like a research paper.</h3>
      <p>Simply can build a calm prerequisite canvas for the page you are reading.</p>
      <div class="actions">
        <button class="primary" id="simply-analyze" type="button">Analyze</button>
        <button class="secondary" id="simply-dismiss" type="button">Dismiss</button>
      </div>
      <div class="status" id="simply-status"></div>
      <ul id="simply-results"></ul>
      <button class="primary open" id="simply-open" type="button" hidden>Open full guide ↗</button>
    </section>
  `,document.documentElement.append(e);let a=i.querySelector(`#simply-analyze`),l=i.querySelector(`#simply-dismiss`),u=i.querySelector(`#simply-open`),d=i.querySelector(`#simply-status`),f=i.querySelector(`#simply-results`),p=null;l?.addEventListener(`click`,()=>e.remove()),a?.addEventListener(`click`,async()=>{if(!(!d||!f||!a||!u)){a.disabled=!0,u.hidden=!0,d.textContent=`Reading the paper...`,f.innerHTML=``;try{let e=s(),n=await fetch(`${t}/api/analyze`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e)});if(!n.ok)throw Error(`Could not analyze this paper yet.`);let r=await n.json();p=r.id??null;let i=(r.lessons??[]).length;d.textContent=i?`Found ${i} prerequisite ideas. Open the full guide for the lessons.`:`No prerequisites detected for this page.`,f.innerHTML=c(r.lessons),u.hidden=i===0}catch(e){d.textContent=e instanceof Error?e.message:`Could not reach the Simply API.`}finally{a.disabled=!1}}}),u?.addEventListener(`click`,()=>{if(!(!d||!u)){if(!p){d.textContent=`Analyze first.`;return}window.open(`${n}/guide?id=${encodeURIComponent(p)}`,`_blank`,`noopener`),d.textContent=`Opened the full guide in a new tab.`}})}chrome.runtime.onMessage.addListener((e,t,n)=>e?.type===`SIMPLY_COLLECT_PAPER`?(n(s()),!0):!1),document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,l,{once:!0}):l();