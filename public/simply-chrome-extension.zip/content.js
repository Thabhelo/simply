var e=`http://localhost:8787`,t=`simply-research-widget`;function n(e){return document.querySelector(`meta[name="${e}"], meta[property="${e}"]`)?.content}function r(e){return[`arxiv.org`,`openreview.net`,`biorxiv.org`,`medrxiv.org`,`ssrn.com`,`aclanthology.org`,`proceedings.mlr.press`,`papers.nips.cc`,`neurips.cc`,`ieee.org`,`springer.com`,`sciencedirect.com`,`nature.com`,`science.org`,`frontiersin.org`,`plos.org`].some(t=>e.endsWith(t))}function i(){let e=window.location.hostname.toLowerCase(),t=window.location.pathname.toLowerCase(),i=document.body.innerText.toLowerCase(),a=!!n(`citation_title`)||!!n(`citation_pdf_url`)||!!n(`dc.title`),o=/\babstract\b/.test(i)&&/\b(introduction|references|method|methods|results|conclusion)\b/.test(i);return r(e)||t.endsWith(`.pdf`)||/^\/pdf\//.test(t)||a||/\bdoi:\s*10\.\d{4,9}\//i.test(document.body.innerText)||o}function a(){let e=window.getSelection()?.toString().trim(),t=document.body.innerText.trim(),r=e||t;return{title:n(`citation_title`)||n(`dc.title`)||document.title.replace(/\s+-\s+Google Chrome$/,``)||`Untitled research paper`,url:window.location.href,text:r?r.slice(0,8e4):void 0}}function o(e){return(e??[]).slice(0,4).map(e=>`<li><span>${e.area}</span><strong>${e.title}</strong><em>${e.intuition}</em></li>`).join(``)}function s(){if(document.getElementById(t)||!i())return;let n=document.createElement(`div`);n.id=t;let r=n.attachShadow({mode:`open`});r.innerHTML=`
    <style>
      :host {
        all: initial;
        color-scheme: light;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      .panel {
        animation: slide-in 420ms cubic-bezier(0.22, 1, 0.36, 1);
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(22px) saturate(180%);
        border: 1px solid rgba(0, 0, 0, 0.08);
        border-radius: 22px;
        bottom: 24px;
        box-shadow: 0 24px 64px rgba(15, 23, 42, 0.14);
        box-sizing: border-box;
        color: #111;
        padding: 16px;
        position: fixed;
        right: 24px;
        width: 320px;
        z-index: 2147483647;
      }

      .top {
        align-items: center;
        display: flex;
        justify-content: space-between;
        gap: 12px;
      }

      .brand {
        font-size: 13px;
        font-weight: 650;
        letter-spacing: -0.02em;
      }

      .pill {
        border: 1px solid rgba(232, 100, 42, 0.28);
        border-radius: 999px;
        color: #c24a1a;
        font-size: 11px;
        padding: 5px 8px;
      }

      h3 {
        font-size: 18px;
        font-weight: 520;
        letter-spacing: -0.03em;
        line-height: 1.12;
        margin: 14px 0 8px;
      }

      p, .status {
        color: rgba(0, 0, 0, 0.58);
        font-size: 13px;
        line-height: 1.45;
        margin: 0;
      }

      .actions {
        display: flex;
        gap: 8px;
        margin-top: 14px;
      }

      button {
        border: 0;
        border-radius: 999px;
        cursor: pointer;
        font: inherit;
        font-size: 13px;
        min-height: 36px;
        padding: 0 13px;
      }

      .primary {
        background: #111;
        color: #fff;
      }

      .secondary {
        background: rgba(0, 0, 0, 0.05);
        color: rgba(0, 0, 0, 0.68);
      }

      ul {
        display: grid;
        gap: 8px;
        list-style: none;
        margin: 14px 0 0;
        padding: 0;
      }

      li {
        background: rgba(0, 0, 0, 0.035);
        border-radius: 12px;
        color: #111;
        font-size: 13px;
        padding: 9px 10px;
      }

      li span {
        color: rgba(0, 0, 0, 0.48);
        display: block;
        font-size: 10px;
        margin-bottom: 3px;
        text-transform: uppercase;
      }

      li strong {
        display: block;
        font-size: 13px;
      }

      li em {
        color: rgba(0, 0, 0, 0.55);
        display: block;
        font-size: 12px;
        font-style: normal;
        margin-top: 3px;
      }

      @keyframes slide-in {
        from {
          opacity: 0;
          transform: translateY(12px) translateX(18px);
        }

        to {
          opacity: 1;
          transform: translateY(0) translateX(0);
        }
      }
    </style>
    <section class="panel" aria-label="Simply research paper helper">
      <div class="top">
        <span class="brand">Simply</span>
        <span class="pill">Paper detected</span>
      </div>
      <h3>This looks like a research paper.</h3>
      <p>Simply can build a calm prerequisite canvas for the page you are reading.</p>
      <div class="actions">
        <button class="primary" id="simply-analyze" type="button">Analyze</button>
        <button class="secondary" id="simply-dismiss" type="button">Dismiss</button>
      </div>
      <div class="status" id="simply-status"></div>
      <ul id="simply-results"></ul>
    </section>
  `,document.documentElement.append(n);let s=r.querySelector(`#simply-analyze`),c=r.querySelector(`#simply-dismiss`),l=r.querySelector(`#simply-status`),u=r.querySelector(`#simply-results`);c?.addEventListener(`click`,()=>n.remove()),s?.addEventListener(`click`,async()=>{if(!(!l||!u||!s)){s.disabled=!0,l.textContent=`Reading the paper...`,u.innerHTML=``;try{let t=await fetch(`${e}/api/analyze`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(a())});if(!t.ok)throw Error(`Could not analyze this paper yet.`);let n=await t.json();l.textContent=`Found ${(n.lessons??[]).length} prerequisite lessons.`,u.innerHTML=o(n.lessons)}catch(e){l.textContent=e instanceof Error?e.message:`Could not reach the Simply API.`}finally{s.disabled=!1}}})}chrome.runtime.onMessage.addListener((e,t,n)=>e?.type===`SIMPLY_COLLECT_PAPER`?(n(a()),!0):!1),document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,s,{once:!0}):s();